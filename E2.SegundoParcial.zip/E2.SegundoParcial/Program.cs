﻿using System;

namespace E2.SegundoParcial
{
    class Program
    {
        static void Main(string[] args)
        {
            //crear diccionario 
            //ordenar lista empleados

            /*1. Listado de nómina en el orden original
            2. Listado de nómina ordenado por nombre
            3. Listado de nómina ordenado por salario
            4. Listado de nómina con salario > 3500
            5. Listado de nómina con 77 en el Rfc
            6. Listado de nómina con los JUBILADOS
            7. Listado de nómina agrupado por área*/
        }
    }
}
